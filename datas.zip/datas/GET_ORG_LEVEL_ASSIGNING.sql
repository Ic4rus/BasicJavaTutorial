create or replace FUNCTION "GET_ORG_LEVEL_ASSIGNING" 
(employeeId IN NUMBER) 
RETURN VARCHAR2 
-- cu phap select F_GET_ORG_PEER_LEVEL_BY_PATH('%/148841/148842/149014/255726/%',5, '10/08/2015') from dual
-- tham so: Id cua user dang login
-- ham lay ve danh sach cac don vi cha + chinh no + duoi no 1 cap

IS
  strParentIds NUMBER(10) DEFAULT 0;
  strChildIds NVARCHAR2(4000) DEFAULT '';
  outputIds NVARCHAR2(4000) DEFAULT '';       
  
  parentId NUMBER(10) DEFAULT 0;   
  currentPath NVARCHAR2(4000) DEFAULT '';
  currentId NUMBER(10) DEFAULT 0;   
  currentLevel NUMBER(10) DEFAULT 0;  
BEGIN
  SELECT DISTINCT r.SYS_ORGANIZATION_ID INTO currentId
  FROM USER_ROLE r
  INNER JOIN SYS_ROLE sr
  ON (sr.CODE = 'LDDV' OR sr.CODE = 'TTDV') AND r.SYS_ROLE_ID = sr.SYS_ROLE_ID
  WHERE r.SYS_USER_ID = employeeId
  AND rownum = 1;
  
  SELECT ORG_PARENT_ID INTO parentId from VHR_ORG where SYS_ORGANIZATION_ID = currentId;
  SELECT PATH INTO currentPath from VHR_ORG where SYS_ORGANIZATION_ID = currentId;
  SELECT ORG_LEVEL INTO currentLevel from VHR_ORG where SYS_ORGANIZATION_ID = currentId;
  
  --SELECT F_GET_ORG_PEER_LEVEL_BY_PATH(currentPath, currentLevel + 1, TO_CHAR(SYSDATE,'dd/MM/yyyy')) INTO strChildIds from dual;
  SELECT F_GET_REAL_PARENT_ORG(parentId) INTO strParentIds FROM dual;
  
  --strChildIds := REPLACE(strChildIds,'/',',');

  outputIds := TO_CHAR(currentId) || ',' || TO_CHAR(strParentIds);  
  
  RETURN outputIds;
END;