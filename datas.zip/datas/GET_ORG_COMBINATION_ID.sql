create or replace Function GET_ORG_COMBINATION_ID 
return number is v_id NUMBER;
BEGIN
SELECT ORG_COMBINATION_MAP_SEQ.NEXTVAL
INTO v_id
FROM DUAL;
RETURN v_id;
End;