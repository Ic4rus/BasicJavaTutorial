create or replace Function GET_MISSION_ID 
return number is v_id NUMBER;
BEGIN
SELECT MISSION_SEQ.NEXTVAL
INTO v_id
FROM DUAL;
RETURN v_id;
End;