create or replace FUNCTION "CHECK_VHR_ORG_ROOT" (orgId IN Long)
RETURN INTEGER
--Tham so: orgId la Id cua don vi can kiem tra
-- ham kiem tra ID don vi VHR co la nut ao hay ko, 1 la nut ao, 0 la nut that

IS 
  tmp INTEGER DEFAULT 0;
  v_table_has_rows NUMBER(1) DEFAULT 0;
BEGIN
  select nvl(max(1),0)   into v_table_has_rows from user_role
        join sys_role on sys_role.sys_role_id = user_role.sys_role_id and (sys_role.code = 'TTDV' or sys_role.code = 'LDDV')
        where sys_organization_id = orgId;
        
        if v_table_has_rows = 1 THEN tmp:=0;
        ELSE
          tmp:=1;
        END IF;
  RETURN tmp;
END;