create or replace Function GET_SOURCE_MAP_ID 
return number is v_id NUMBER;
BEGIN
SELECT source_map_seq.NEXTVAL
INTO v_id
FROM DUAL;
RETURN v_id;
End;