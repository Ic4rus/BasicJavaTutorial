create or replace FUNCTION "GET_CHILD_ORG_LEVEL_BY_PATH" 
(in_org IN Long, in_org_level IN NUMBER,in_date_current IN VARCHAR2, step IN NUMBER DEFAULT 0 ) 
RETURN VARCHAR2 
-- cu phap select F_GET_ORG_PEER_LEVEL_BY_PATH('%/148841/148842/149014/255726/%',5, '10/08/2015') from dual
-- tham so: path cua don vi can lay con, level cua don vi + 1, ngay thang
-- ham lay ve danh sach cac don vi con thuoc don vi dang xet
-- xu ly:
-- duyet cac don vi con truc tiep
-- neu don vi dang xet co lanh dao (check trong bang user role) thi them vao ket qua tra ve
-- neu don vi dang xet KHONG co lanh dao (-> day la don vi ao) thi duyet tiep con cua no

IS
  tmp NVARCHAR2(4000) DEFAULT '';
  tmp2 NVARCHAR2(4000) DEFAULT '';
  v_table_has_rows NUMBER(1) DEFAULT 0;
  /*Lay danh sach don vi cha*/
   CURSOR c_org
   IS    
        SELECT vo.SYS_ORGANIZATION_ID, vo.PATH FROM VHR_ORG vo WHERE 1=1
            AND vo.EFFECTIVE_START_DATE <= TO_DATE( in_date_current ,'dd/mm/yyyy hh24:mi:ss') 
            AND (vo.EFFECTIVE_END_DATE IS NULL OR vo.EFFECTIVE_END_DATE >= TO_DATE( in_date_current ,'dd/mm/yyyy hh24:mi:ss'))
            AND vo.ORG_PARENT_ID = in_org
            AND vo.ORG_LEVEL = in_org_level
      ;            
BEGIN
  tmp := ',';
  FOR p_org IN c_org
   LOOP     
      select nvl(max(1),0)   into v_table_has_rows from user_role
        join sys_role on sys_role.sys_role_id = user_role.sys_role_id and (sys_role.code = 'TTDV' or sys_role.code = 'LDDV')
        where sys_organization_id = p_org.SYS_ORGANIZATION_ID;

      IF v_table_has_rows = 1 THEN   
        IF (p_org.SYS_ORGANIZATION_ID IS NOT NULL) THEN
            tmp := tmp || p_org.SYS_ORGANIZATION_ID || ',';
        END IF;    
      ELSE
        --goi de quy
        IF step <= 1 THEN
          tmp2 := GET_CHILD_ORG_LEVEL_BY_PATH(p_org.SYS_ORGANIZATION_ID,in_org_level+1,in_date_current,step + 1 );
          IF tmp2 <> ',' THEN
            tmp := tmp || tmp2;
          END IF;  
        END IF;  
      END IF;
   END LOOP;

  RETURN REPLACE(tmp,',,',',');
END;